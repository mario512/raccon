<?php

// Автозагрузка классов
class Loader
{

    public function autoLoad()
    {

        spl_autoload_register(function ($className) {

            $patch = array(
                '/Models/',
                '/Components/'
            );

            foreach ($patch as $patсh) {

                $patсh = ROOT . $patсh . $className . '.php';

                if (is_file($patсh)) {
                    include_once $patсh;
                }
            }
        });
    }

    public function load($component = '', $data = '')
    {

        $segments       = explode('_', $component);
        $patchFile      = ROOT;
        $name           = end($segments);
        $objectName     = ucfirst($name);

        foreach ($segments as $segment) {
            $patchFile .= '/' . ucfirst($segment);
        }

        $patchFile .= '.php';
        
        if (is_file($patchFile)) {
            include_once $patchFile;
            $newObject = new $objectName($data);
            return $newObject;
        }
    }

    public static function getData($dataPatch, $returnData = false)
    {

        $segments       = explode('_', $dataPatch);
        $patchFile      = ROOT;
        $name           = end($segments);

        foreach ($segments as $segment) {
            $patchFile .= '/' . ucfirst($segment);
        }

        $patchFile .= '.php';

        if (is_file($patchFile)) {
            if ($returnData === false) {
                return $patchFile;
            } else {
                return include($patchFile);
            }
        }
    }
}

<?php

class Db
{

    private $db;

    public function __construct()
    {

        try {
            //$this->db = new PDO("mysql:host=" . HOST . ";dbname=" . DB_NAME . ";charset=UTF8", USER, PASSWORD, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
            $this->db = new PDO("mysql:host=" . HOST . ";dbname=" . DB_NAME . ";charset=UTF8", USER, PASSWORD);
        } catch (PDOException $e) {
            // throw new Exception('Error: ' . $e->getMessage() . ' Error Code : ' . $e->getCode() . ' <br />');
            if ($e->getCode() === 2002 || $e->getCode() === 1044 || $e->getCode() === 1045) {
                exit('<h2>Not Data Base Connection</h2>');
            }
        }

        return $this->db;
    }

    public function query($query = '', $queryParam = array())
    {
        if ($query) {
            $resultQuery = $this->db->prepare($query);
            if ($queryParam) {
                foreach ($queryParam as $key => $valueParam) {
                    foreach ($valueParam as $param => &$dataParam) {
                        $resultQuery->bindParam(":$param", $dataParam['data'], $dataParam['type']);
                    }
                    $resultQuery->execute();
                }
            } else {
                $resultQuery->execute();
            }

            $last_id = $this->db->lastInsertId();

            $data = $resultQuery->fetchAll(PDO::FETCH_ASSOC);

            $result             = new stdClass();
            $result->row        = isset($data[0]) ? $data[0] : [];
            $result->rows       = $data;
            $result->num_rows   = count($data);
            $result->last_id    = $last_id;

            return $result;
        }
    }

    public function __destruct()
    {
        $this->db = NULL;
    }
}
